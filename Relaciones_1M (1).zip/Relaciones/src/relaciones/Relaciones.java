
package relaciones;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class Relaciones {
    
        public static ArrayList<Veterinarian> readVeterinarian(String filePath){
        
        ArrayList <Veterinarian> vets = new ArrayList<>();
        
        String line = "";
        String idVet = "";
        String name = "";
        int experience = 0;
        
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            reader.readLine();
            
            while((line=reader.readLine())!=null){
                
                String[] parts = line.split(",");
                
                if(parts.length>=3){
                    idVet = parts[0].trim();
                    name = parts[1].trim();
                    experience = Integer.parseInt(parts[2].trim());
                   
                    try{
                        vets.add(new Veterinarian(idVet,name,experience));
                    }catch(Exception e){
                        System.out.println("Error creating the object: " + e.getMessage());
                    }
                }else{
                    System.out.println("Incomplete data to create the object");
                }
                
            }
            reader.close();    
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return vets;
    }
   
    public static ArrayList<Animal> readAnimal(String filePath, ArrayList<Veterinarian> vets){
        
        ArrayList <Animal> animals = new ArrayList<>();
        
        String line = "";
        String idAnimal = "";
        String name = "";
        int age = 0;
        String idVet = "";
        Animal tempA;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            reader.readLine();
            
            while((line=reader.readLine())!=null){
                
                String[] parts = line.split(",");
                
                if(parts.length>=4){
                    idAnimal = parts[0].trim();
                    name = parts[1].trim();
                    age = Integer.parseInt(parts[2].trim());
                    idVet = parts[3].trim();
                   
                    try{
                        tempA = new Animal(idAnimal,name,age);
                        animals.add(tempA);
                        
                        for(Veterinarian v: vets){
                            if(idVet.equals(v.getIdVet())){
                                v.addAnimal(tempA);
                            }
                        }
                        
                    }catch(Exception e){
                        System.out.println("Error creating the object: " + e.getMessage());
                    }
                }else{
                    System.out.println("No hay suficientes datos para crear el objeto");
                }
                
            }
            reader.close();    
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return animals;
    }

    public static void main(String[] args) {
        
        //Crear la lista de veterinarios
        ArrayList <Veterinarian> vets = readVeterinarian("./Veterinarios.txt");
        
        //Crear la lista de animales y pasarle la lista de veterinarios
        ArrayList <Animal> animals = readAnimal("./Animals.txt", vets);
        
        //Imprimir la lista de animales
        System.out.println("ANIMALS INFORMATION");
        for(Animal a: animals){
            System.out.println(a.toString());
        }
        
        //Imprimir la lista de veterinarios
        System.out.println("\nVETERINARIANS INFORMATION");
        for(Veterinarian v: vets){
            System.out.println(v.toString()+ "\n");
        }
    }
    
}
