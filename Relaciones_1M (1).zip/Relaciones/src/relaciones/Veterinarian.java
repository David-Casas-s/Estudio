
package relaciones;
import java.util.ArrayList;

public class Veterinarian {
    
    private String idVet;
    private String name;
    private int experience;
    private ArrayList <Animal> animals;
    
    public Veterinarian(){
    }
    
    public Veterinarian(String idVet, String name, int experience){
        this.idVet = idVet;
        this.name = name;
        this.experience = experience;
        this.animals = new ArrayList<>();
    }
    
    public void addAnimal(Animal animal){
        this.animals.add(animal);
    }
    
    public String getIdVet(){
        return this.idVet;
    }
    
    public String toString(){
        String str = "Id Vet: " + this.idVet + "\n";
        str += "Vet Name: " + this.name + "\n";
        str += "Vet experience: " + this.experience + "\n";
        str += "Animals in charge: \n";
        for(Animal a: this.animals){
            str += a.toString() + "\n";
        }
        return str;
    }
    
}
