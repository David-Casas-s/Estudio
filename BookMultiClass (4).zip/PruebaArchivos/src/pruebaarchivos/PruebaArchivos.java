package pruebaarchivos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class PruebaArchivos {
    
    public static ArrayList<Book> readFile(String filePath){
        
        ArrayList <Book> books = new ArrayList<>();
        
        String line = "";
        String name = "";
        String authorName = "";
        String id = "";
        String nationality = "";
        double value = 0;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            reader.readLine();
            
            while((line=reader.readLine())!=null){
                
                String[] parts = line.split(",");
                
                if(parts.length>=5){
                    name = parts[0];
                    value = Double.parseDouble(parts[1]);
                    authorName = parts[2];
                    id = parts[3];
                    nationality = parts[4];
                    
                    try{
                        books.add(new Book(name,value,authorName,id,nationality));
                    }catch(Exception e){
                        System.out.println("Error creating the object: " + e.getMessage());
                    }
                }else{
                    System.out.println("No hay suficientes datos para crear el objeto");
                }
                
            }
            
            reader.close();
            
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return books;
    }

    public static void writeToFile(String filePath, ArrayList<Book> books){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))){
            
            writer.write("LIST OF BOOKS\n");
            writer.write("Book Name, Book Value");
            writer.newLine();
            
            //Escribir la información de los objetos de la lista
            String line = "";
            for(Book b: books){
                line = b.toString();
                writer.write(line);
                writer.newLine();
            }
            
            //Cerramos el Buffer de escritura
            writer.close();
            System.out.println("The file was created: " + filePath);
            
        }catch(IOException e){
            System.err.println("Error: File could not be created" + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        
        System.out.println("READING THE FILE");
        //En la lista books quedan almacenados los objetos que se crearon
        // al leer el archivo info_books
        ArrayList <Book> books = readFile("./info_books.txt");
        
        // Imprimimos los objetos que se crearon
        System.out.println("PRINTING THE BOOKS CREATED WITH AUTHORS INFORMATION");
        for(Book b: books){
            System.out.println(b.toString());
        }
        
        //Creamos un reporte con los objetos creados
        writeToFile("./BooksReport.txt", books);
        
    }
    
}
