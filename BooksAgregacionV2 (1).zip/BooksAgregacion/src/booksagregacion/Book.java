
package booksagregacion;

public class Book {
    
    private String name;
    private double price;
    private Author author;
    
    public Book(){
        this.name = "";
        this.price = 0.0;
    }
    
    public Book(String name, double price, Author author){
        this.setName(name);
        this.price = price;
        this.author = author;
    }
    
    public void setName(String name){
        if (name == null || name.isBlank() || name.matches(".*[-!@#$%^&*()+=<>?/].*")){
            throw new IllegalArgumentException("Product name is not valid.");
        }
        else{
            this.name = name;
        }
    }
    
    public void setAuthor(Author author){
        this.author = author;
    }
    public Author getAuthor(){
        return this.author;
    }
    
    @Override
    public String toString(){
        String temp = this.name + "," + this.price + "," + this.author.toString();
        return temp;
    }
    
}
