
package booksagregacion;

public class Author {
    private String name;
    private String id;
    private String nationality;
    
    public Author(){
    }
    public Author(String id){
        this.name = "";
        this.id = id;
        this.nationality = "";
    }
    public Author(String name, String id, String nationality){
        this.name = name;
        this.id = id;
        this.nationality = nationality;
    }
    public void setName(String name){
        if (name == null || name.isBlank() || name.matches(".*[-!@#$%^&*()+=<>?/].*")){
            throw new IllegalArgumentException("Product name is not valid.");
        }
        else{
            this.name = name;
        }
    }
    public void setId(String id){
        this.id = id;
    }
    public void setNationality(String nationality){
        this.nationality = nationality;
    }
    public String getId(){
        return this.id;
    }
    public String getName(){
        return this.name;
    }
    public String getNationality(){
        return this.nationality;
    }
    @Override
    public String toString(){
        String str = this.name + "," + this.id + "," + this.nationality;
        return str;
    } 
}
