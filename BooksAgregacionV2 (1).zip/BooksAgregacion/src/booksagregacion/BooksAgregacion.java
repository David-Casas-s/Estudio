
package booksagregacion;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class BooksAgregacion {
    
    public static ArrayList<Book> readBooks(String filePath, ArrayList<Author> authors){
        
        ArrayList <Book> books = new ArrayList<>();
        
        String line = "";
        String name = "";
        String id = "";
        Author tempA = null;
        double value = 0;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            reader.readLine();
            
            while((line=reader.readLine())!=null){
                
                String[] parts = line.split(",");
                
                if(parts.length>=3){
                    name = parts[0].trim();
                    value = Double.parseDouble(parts[1].trim());
                    id = parts[2].trim();
                   
                    try{
                        for(Author a: authors){
                            if(id.equals(a.getId())){
                                tempA = a;
                            }
                        }
                        
                        books.add(new Book(name,value,tempA));
                    }catch(Exception e){
                        System.out.println("Error creating the object: " + e.getMessage());
                    }
                }else{
                    System.out.println("No hay suficientes datos para crear el objeto");
                }
                
            }
            reader.close();    
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return books;
    }
    
    public static ArrayList<Author> readAuthors(String filePath){
        
        ArrayList <Author> authors = new ArrayList<>();
        
        String line = "";
        String authorName = "";
        String id = "";
        String nationality = "";
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            reader.readLine();
            
            while((line=reader.readLine())!=null){
                
                String[] parts = line.split(",");
                
                if(parts.length>=3){
                    authorName = parts[0].trim();
                    id = parts[1].trim();
                    nationality = parts[2].trim();
                    
                    try{
                        authors.add(new Author(authorName,id,nationality));
                    }catch(Exception e){
                        System.out.println("Error creating the object: " + e.getMessage());
                    }
                }else{
                    System.out.println("No hay suficientes datos para crear el objeto");
                }     
            }
            
            reader.close();   
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return authors;
    }
  
    public static void main(String[] args) {
        
        ArrayList <Book> books;
        ArrayList <Author> authors;
        
        System.out.println("Creating the list of Authors");
        authors = readAuthors("./info_authors.txt");
        
        System.out.println("Creating the list of Books");
        books = readBooks("./info_books.txt", authors);
        
        System.out.println("\nINFORMATION OF THE BOOKS CREATED");
        for(Book b: books){
            System.out.println(b.toString());
        }  
    }  
}
