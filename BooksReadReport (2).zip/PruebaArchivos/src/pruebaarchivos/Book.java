
package pruebaarchivos;


public class Book {
    
    private String name;
    private double price;
    
    public Book(){
    }
    
    public Book(String name, double price){
        this.setName(name);
        this.price = price;
    }
    
    public void setName(String name){
        if (name == null || name.isBlank() || name.matches(".*[-!@#$%^&*()+=<>?/].*")){
            throw new IllegalArgumentException("Product name is not valid.");
        }
        else{
            this.name = name;
        }
    }
    public String toString(){
        String temp = "Name: " + this.name + " Value: " + this.price;
        return temp;
    }
    public String fileString(){
        String temp = this.name + "," + this.price;
        return temp;
    }
}
