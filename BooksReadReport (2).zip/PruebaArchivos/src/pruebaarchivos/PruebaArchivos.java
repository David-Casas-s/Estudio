
package pruebaarchivos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class PruebaArchivos {
    
    public static ArrayList<Book> readFile(String filePath){
        //Creacion arraylist para guardar los libros
        ArrayList <Book> books = new ArrayList<>();
        //Variable temporales para almacenar la informacion que viene del archivo
        String line = "";
        String name = "";
        double value = 0;
        
        //Creamos un objeto llamado reader de tipo BufferedReader y en su interior
        // esta un objeto tipo FileReader para leer el archivo de texto caracter por caracter
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // En la variable reader esta la informacion del archivo en memoria RAM
            //Con readLine leemos linea a linea la informacion del archivo
            // Se lee esta primera para quitar el encabezado
            reader.readLine();
            
            // Se hace un while para recorrer todas las lineas del archivo
            while((line=reader.readLine())!=null){
                // Se crea un vector de tipo String para separar los valores de cada línea
                // del archivo.
                String[] parts = line.split(",");
                // Se pregunta si hay al menos dos valores para asignar la informacion a nuestras
                // variables auxiliares
                if(parts.length>=2){
                    // Asignamos el primer valor a la variable name
                    name = parts[0];
                    // Convertimos el segundo valor a double para asignarlo a la variable
                    value = Double.parseDouble(parts[1]);
                    
                    // Vamos a crear nuestro objeto pero puede fallar por la validación de los datos
                    // por eso tenemos que usar try y catch.
                    try{
                        // Com books.add asignamos un nuevo objeto al ArrayList
                        // Llamamos al constructor sobrecargado de Book y le asignamos
                        // los valores que vienen del archivo
                        books.add(new Book(name,value));
                    }catch(Exception e){
                        //El programa lanza excepction cuando el nombre es inválido
                        System.out.println("Error creating the object: " + e.getMessage());
                    }
                    
                }else{
                    System.out.println("No hay suficientes datos para crear el objeto");
                }
                
            }
            //CERRAMOS EL BUFFEREDREADER
            reader.close();
            
        } catch (IOException e) {
            // El programa lanza exception cuando no puede leer el archivo
            System.err.println("Error reading file: " + e.getMessage());
        }
        // Devolvemos la variable que almacena la lista de objetos creados
        return books;
    }

    public static void writeToFile(String filePath, ArrayList<Book> books){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))){
            //Escribimos el encabezado del informe
            writer.write("LIST OF BOOKS\n");
            writer.write("Book Name, Book Value");
            writer.newLine();
            
            //Escribir la información de los objetos de la lista
            String line = "";
            for(Book b: books){
                line = b.fileString();
                writer.write(line);
                writer.newLine();
            }
            
            //Cerramos el Buffer de escritura
            writer.close();
            System.out.println("The file was created: " + filePath);
            
        }catch(IOException e){
            System.err.println("Error: File could not be created" + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        
        System.out.println("READING THE FILE");
        //En la lista books quedan almacenados los objetos que se crearon
        // al leer el archivo info_books
        ArrayList <Book> books = readFile("./info_books.txt");
        
        // Imprimimos los objetos que se crearon
        System.out.println("PRINTING THE BOOKS CREATED");
        for(Book b: books){
            System.out.println(b.toString());
        }
        
        //Creamos un reporte con los objetos creados
        writeToFile("./BooksReport.txt", books);
        
    }
    
}
